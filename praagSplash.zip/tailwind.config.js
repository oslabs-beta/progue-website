module.exports = {
  plugins: [require("daisyui")],
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],

  // daisyUI config
  daisyui: {
    styled: true,
    themes: [
      {
        mytheme: {
          primary: "#570DF8",
          secondary: "#c026d3",
          accent: "#0891b2",
          neutral: "#292524",
          "base-100": "#ffffff",
          info: "#3ABFF8",
          success: "#36D399",
          warning: "#FBBD23",
          error: "#F87272",

          "--rounded-box": "1rem",
          "--rounded-btn": "0.5rem",
          "--rounded-badge": "1.9rem",
          "--animation-btn": "0.25s",
          "--animation-input": "0.2s",
          "--btn-text-case": "uppercase",
          "--btn-focus-scale": "0.95",
          "--border-btn": "1px",
          "--tab-border": "1px",
          "--tab-radius": "0.5rem"
        }
      }
    ],
    rtl: false,
    prefix: "",
    darkTheme: "garden"
  }
};
