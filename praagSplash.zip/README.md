![kafkaPRAAG-logo-transparent](https://github.com/oslabs-beta/progue-website/assets/97624308/4c5f6488-44bc-437a-92df-cc4649bf5217)

Welcome to the official splash page for kafkaPRAAG! All will be revealed!

## The team

Created by OSlabs' Cat Kim Sherry Lu, Hank McGill, and Richard Wu.

## Express Server

This app has a minimal [Express server](https://expressjs.com/) implementation. After running a full build, you can preview the build using the command:

```
npm run serve
```

Then visit [http://localhost:8080/](http://localhost:8080/)
